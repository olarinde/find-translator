/*
 * Copyright (c) 2016 Koweg Software Solutions Limited
 * London
 * All rights reserved.
 */

package com.hsbc.dtc.poc.tests.hooks;



public class ServerHook {

}
