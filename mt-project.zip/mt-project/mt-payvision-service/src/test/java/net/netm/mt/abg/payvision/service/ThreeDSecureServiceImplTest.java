/**
 * 
 */
package net.netm.mt.abg.payvision.service;

import static org.junit.Assert.*;

import net.netm.mt.abg.payvision.service.dto.PreparePaymentRequestDTO;
import net.netm.mt.abg.payvision.service.dto.PreparePaymentResponseDTO;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

/**
 * @author larinde
 *
 */
public class ThreeDSecureServiceImplTest {
	
	private ThreeDSecureService threeDSecureService;

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		threeDSecureService = new ThreeDSecureServiceImpl();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		threeDSecureService = null;
	}

	/**
	 * Test method for {@link net.netm.mt.abg.payvision.service.ThreeDSecureServiceImpl#checkEnrollment(net.netm.mt.abg.payvision.service.dto.PreparePaymentRequestDTO)}.
	 */
	@Test
	public void testCheckEnrollment() {
		PreparePaymentRequestDTO requestDTO = new PreparePaymentRequestDTO();
		requestDTO.setAccountOwnerLastname("Doe");
		requestDTO.setAccountNumber("5200000000000007");
		requestDTO.setGrossAmount("33.7");
		requestDTO.setCcExpireDate("01-2011");
		PreparePaymentResponseDTO responseDTO = threeDSecureService.checkEnrollment(requestDTO);
		assertNotNull(responseDTO);
		assertEquals("0", responseDTO.getStatusCode());
	}

	/**
	 * Test method for {@link net.netm.mt.abg.payvision.service.ThreeDSecureServiceImpl#paymentUsingIntegratedMPI(net.netm.mt.abg.payvision.service.dto.PaymentBookingRequestDTO)}.
	 */
	@Test
	@Ignore
	public void testPaymentUsingIntegratedMPI() {
		fail("Not yet implemented");
	}

}
