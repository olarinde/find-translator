

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.transports.http.configuration.ProxyServerType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.cdyne.ws.weatherws.ArrayOfForecast;
import com.cdyne.ws.weatherws.Forecast;
import com.cdyne.ws.weatherws.ForecastReturn;
import com.cdyne.ws.weatherws.Weather;
import com.cdyne.ws.weatherws.WeatherSoap;

public class SoapClient2 {

	private static final Logger LOGGER = LoggerFactory.getLogger(SoapClient2.class);
	private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("EEEE, MMMM d yyyy");
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		long start = new Date().getTime();
		
		
		 
		String proxyHost = "proxy.net-m.de";
		int proxyPort = 3128;
		
		
		
		HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
		httpClientPolicy.setConnectionTimeout(6000);
		httpClientPolicy.setReceiveTimeout(6000);
		httpClientPolicy.setProxyServer(proxyHost);
		httpClientPolicy.setProxyServerPort(proxyPort);
		httpClientPolicy.setProxyServerType(ProxyServerType.HTTP);
		
		Weather _weatherService = new Weather();
		WeatherSoap _weatherSoap = _weatherService.getWeatherSoap();
		Client client = ClientProxy.getClient(_weatherSoap);
		
		HTTPConduit httpConduit = (HTTPConduit) client.getConduit();
		httpConduit.setClient(httpClientPolicy);
		
		LOGGER.debug("done creating instance: {}", _weatherSoap);
		
		long end = new Date().getTime();
		
		
		ForecastReturn forecastReturn = _weatherSoap.getCityForecastByZIP("94025");
		
		System.out.println("City:    " + forecastReturn.getCity());
		System.out.println("State:   " + forecastReturn.getState());
		LOGGER.info("City:    {}", forecastReturn.getCity());
		LOGGER.info("State:   {}", forecastReturn.getState());
		ArrayOfForecast arrayOfForecast  = forecastReturn.getForecastResult();
		
		for (Forecast forecast : arrayOfForecast.getForecast()) {
			LOGGER.info("--- Temp(day-high): {}", forecast.getTemperatures().getDaytimeHigh());
			LOGGER.info("--- Desc:           {}", forecast.getDesciption());
		}

	}

}
