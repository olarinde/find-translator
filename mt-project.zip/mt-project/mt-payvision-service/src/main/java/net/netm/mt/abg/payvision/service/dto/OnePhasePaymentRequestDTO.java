/**
 * 
 */
package net.netm.mt.abg.payvision.service.dto;

import java.io.Serializable;

/**
 * @author larinde
 * 
 */
public class OnePhasePaymentRequestDTO extends AbstractRequestDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3153599422284496055L;
	public final String REQUEST_TYPE = "OnePhasePayment";
//	private String username;
//	private String password;
//	private String requestID;
//	private String serviceType;
//	private String paymentType;
//	private String version;
//	private String transactionID;
	// interim status
	private String code;
	
	private String description; // Description=Klingelton
	private String grossAmount; // &GrossAmount=50
	private String currency; // Currency=EURO-CENT
	private String apType; // ApType=cc
	private String cardType; // &CardType=Visa
	private String cvv;// CVV=029
	private String ccExpireDate; // &CcExpireDate=12-2010
	private String accountNumber; // AccountNumber=4907639999990022
	private String productURL;// ProductURL=http://net-m.de/product
	private String errorURL;// ErrorURL=http://netm-m.de/error
	private String accountOwnerName; // AccountOwnerName=John
	private String accountOwnerLastname; // AccountOwnerLastName=Doe


	
	/**
	 * client-transaction-id=P0159546670&
		service-type=web&
		payment-type=otp&
		account-number=XXXXXXXXXXXX4744&
		password=passsoundaccount&
		currency=EUR&
		version=1.0&
		account-owner-last-name=XXXert&
		username=soundaccount&
		description=FULLTRACK&
		cvv=XXX&
		originator-id=PGW&
		remote-ip=84.58.56.244&
		msisdn=00499999999999&
		item-amount=99&
		provider=PAYVISION_LIVESYSTEM&
		cc-expire-date=05-2011&
		category=55&a
		ccount-owner-name=Xnke&
		terms-of-use=true&
		card-type=Visa&
		user-id=10315&
		ap-type=cc&
		consumer-id=cc_0000007876&
		request-type=onePhasePayment

	 * 
	 * 
	 */
	
	
	/**
	 * Constructor
	 * 
	 */

	public OnePhasePaymentRequestDTO() {
		super();
	}



	public String getCode() {
		return code;
	}



	public void setCode(String code) {
		this.code = code;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public String getGrossAmount() {
		return grossAmount;
	}



	public void setGrossAmount(String grossAmount) {
		this.grossAmount = grossAmount;
	}



	public String getCurrency() {
		return currency;
	}



	public void setCurrency(String currency) {
		this.currency = currency;
	}



	public String getApType() {
		return apType;
	}



	public void setApType(String apType) {
		this.apType = apType;
	}



	public String getCardType() {
		return cardType;
	}



	public void setCardType(String cardType) {
		this.cardType = cardType;
	}



	public String getCvv() {
		return cvv;
	}



	public void setCvv(String cvv) {
		this.cvv = cvv;
	}



	public String getCcExpireDate() {
		return ccExpireDate;
	}



	public void setCcExpireDate(String ccExpireDate) {
		this.ccExpireDate = ccExpireDate;
	}



	public String getAccountNumber() {
		return accountNumber;
	}



	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}



	public String getProductURL() {
		return productURL;
	}



	public void setProductURL(String productURL) {
		this.productURL = productURL;
	}



	public String getErrorURL() {
		return errorURL;
	}



	public void setErrorURL(String errorURL) {
		this.errorURL = errorURL;
	}



	public String getAccountOwnerName() {
		return accountOwnerName;
	}



	public void setAccountOwnerName(String accountOwnerName) {
		this.accountOwnerName = accountOwnerName;
	}



	public String getAccountOwnerLastname() {
		return accountOwnerLastname;
	}



	public void setAccountOwnerLastname(String accountOwnerLastname) {
		this.accountOwnerLastname = accountOwnerLastname;
	}
	
	
	
	
	
	
	

//	/**
//	 * Constructor
//	 * 
//	 * @param requestType
//	 * @param username
//	 * @param password
//	 * @param requestId
//	 * @param serviceType
//	 * @param transactionId
//	 * @param cvv
//	 */
//	public OnePhasePaymentRequestDTO(String username, String password, String requestID, String serviceType, String transactionID, String cvv, String replypath) {
//		super();
//		this.username = username;
//		this.password = password;
//		this.requestID = requestID;
//		this.serviceType = serviceType;
//		this.transactionID = transactionID;
//		this.cvv = cvv;
////		this.replypath = replypath;
//	}

////	public String getUsername() {
////		return username;
////	}
////
////	public void setUsername(String username) {
////		this.username = username;
////	}
////
////	public String getPassword() {
////		return password;
////	}
////
////	public void setPassword(String password) {
////		this.password = password;
////	}
////
////	public String getServiceType() {
////		return serviceType;
////	}
////
////	public void setServiceType(String serviceType) {
////		this.serviceType = serviceType;
////	}
//
//	public String getCvv() {
//		return cvv;
//	}
//
//	public void setCvv(String cvv) {
//		this.cvv = cvv;
//	}
//
////	public String getPaymentType() {
////		return paymentType;
////	}
////
////	public void setPaymentType(String paymentType) {
////		this.paymentType = paymentType;
////	}
//
//	/**
//	 * helper method for building query string
//	 * 
//	 * @return
//	 */
//	public String toQuery() {
//		return "Username=" + username + "&Password=" + password + "&RequestID=" + requestID + "&ServiceType=" + serviceType + "&PaymentType=" + paymentType + "&TransactionID=" + transactionID + "&CVV=" + cvv;
//	}
//
//	public String getCode() {
//		return code;
//	}
//
//	public void setCode(String code) {
//		this.code = code;
//	}
//
////	public String getVersion() {
////		return version;
////	}
////
////	public void setVersion(String version) {
////		this.version = version;
////	}
//
//	@Override
//	public String toString() {
//		return "PaymentBookingRequestDTO [requestType=" + REQUEST_TYPE + ", username=" + username + ", password=" + password + ", requestID=" + requestID + ", serviceType=" + serviceType + ", transactionID=" + transactionID + ", cvv=" + cvv + ", paymentType="
//				+ paymentType + ", version=" + version + ", code=" + code + "]";
//	}
//
//	/**
//	 * @return the requestID
//	 */
//	public String getRequestID() {
//		return requestID;
//	}
//
//	/**
//	 * @param requestID the requestID to set
//	 */
//	public void setRequestID(String requestID) {
//		this.requestID = requestID;
//	}
//
//	/**
//	 * @return the transactionID
//	 */
//	public String getTransactionID() {
//		return transactionID;
//	}
//
//	/**
//	 * @param transactionID the transactionID to set
//	 */
//	public void setTransactionID(String transactionID) {
//		this.transactionID = transactionID;
//	}
//	
	

}
