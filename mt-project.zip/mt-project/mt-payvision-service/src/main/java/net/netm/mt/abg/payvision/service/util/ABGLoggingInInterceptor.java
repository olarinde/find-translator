/**
 * 
 */
package net.netm.mt.abg.payvision.service.util;

import java.io.PrintWriter;

import org.apache.cxf.interceptor.LoggingInInterceptor;

/**
 *
 * @author:  Olarinde Ajai
 * @email:   olarinde.aja@net-m.de
 * @created: Sep 8, 2010 4:36:00 PM 
 */

public class ABGLoggingInInterceptor extends LoggingInInterceptor {

	/**
	 * 
	 */
	public ABGLoggingInInterceptor() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param phase
	 */
	public ABGLoggingInInterceptor(String phase) {
		super(phase);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param lim
	 */
	public ABGLoggingInInterceptor(int lim) {
		super(lim);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param w
	 */
	public ABGLoggingInInterceptor(PrintWriter w) {
		super(w);
		// TODO Auto-generated constructor stub
	}

}
