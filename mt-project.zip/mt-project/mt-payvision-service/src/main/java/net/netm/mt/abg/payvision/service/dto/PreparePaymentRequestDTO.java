/**
 * 
 */
package net.netm.mt.abg.payvision.service.dto;

import java.io.Serializable;

/**
 * @author larinde
 * 
 */
public class PreparePaymentRequestDTO extends AbstractRequestDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8126994437601182761L;


//	private String requestType; // RequestType=PreparePayment
	public final String  REQUEST_TYPE = "PreparePayment";
	private String description; // Description=Klingelton
	private String grossAmount; // &GrossAmount=50
	private String currency; // Currency=EURO-CENT
	private String apType; // ApType=cc
	private String cardType; // &CardType=Visa
	private String cvv;// CVV=029
	private String ccExpireDate; // &CcExpireDate=12-2010
	private String accountNumber; // AccountNumber=4907639999990022
	private String productURL;// ProductURL=http://net-m.de/product
	private String errorURL;// ErrorURL=http://netm-m.de/error
	private String accountOwnerName; // AccountOwnerName=John
	private String accountOwnerLastname; // AccountOwnerLastName=Doe

	public PreparePaymentRequestDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

//	public String getRequestType() {
//		return requestType;
//	}
//
//	public void setRequestType(String requestType) {
//		this.requestType = requestType;
//	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getM2m() {
		return m2m;
	}

	public void setM2m(String m2m) {
		this.m2m = m2m;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getGrossAmount() {
		return grossAmount;
	}

	public void setGrossAmount(String grossAmount) {
		this.grossAmount = grossAmount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getApType() {
		return apType;
	}

	public void setApType(String apType) {
		this.apType = apType;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getCcExpireDate() {
		return ccExpireDate;
	}

	public void setCcExpireDate(String ccExpireDate) {
		this.ccExpireDate = ccExpireDate;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getProductURL() {
		return productURL;
	}

	public void setProductURL(String productURL) {
		this.productURL = productURL;
	}

	public String getErrorURL() {
		return errorURL;
	}

	public void setErrorURL(String errorURL) {
		this.errorURL = errorURL;
	}

	public String getRemoteIp() {
		return remoteIp;
	}

	public void setRemoteIp(String remoteIp) {
		this.remoteIp = remoteIp;
	}

	public String getAccountOwnerName() {
		return accountOwnerName;
	}

	public void setAccountOwnerName(String accountOwnerName) {
		this.accountOwnerName = accountOwnerName;
	}

	public String getAccountOwnerLastname() {
		return accountOwnerLastname;
	}

	public void setAccountOwnerLastname(String accountOwnerLastname) {
		this.accountOwnerLastname = accountOwnerLastname;
	}

	@Override
	public String toString() {
		return "PreparePaymentRequestDTO [requestType=" + REQUEST_TYPE + ", version=" + version + ", username=" + username + ", password=" + password + ", requestId=" + requestId + ", serviceType=" + serviceType + ", paymentType=" + paymentType + ", serviceId=" + serviceId + ", m2m=" + m2m
				+ ", category=" + category + ", description=" + description + ", grossAmount=" + grossAmount + ", currency=" + currency + ", apType=" + apType + ", cardType=" + cardType + ", cvv=" + cvv + ", ccExpireDate=" + ccExpireDate + ", accountNumber=" + accountNumber + ", productURL="
				+ productURL + ", errorURL=" + errorURL + ", remoteIp=" + remoteIp + ", accountOwnerName=" + accountOwnerName + ", accountOwnerLastname=" + accountOwnerLastname + "]";
	}

	public String toQuery() {
		return "RequestType=" + REQUEST_TYPE + "&Version=" + version + "&Username=" + username + "&Password=" + password + "&RequestID=" + requestId + "&ServiceType=" + serviceType + "&PaymentType=" + paymentType + "&ServiceID=" + serviceId + "&M2M=" + m2m + "&Category=" + category + "&Description="
				+ description + "&Currency=" + currency + "&CardType=" + cardType + "&CVV=" + cvv + "&CcExpireDate=" + ccExpireDate + "&AccountNumber=" + accountNumber + "&ProductURL=" + productURL + "&ErrorURL=" + errorURL + "&RemoteIP=" + remoteIp + "&AccountOwnerName=" + accountOwnerName
				+ "&AccountOwnerName=" + accountOwnerLastname;
	}

}
