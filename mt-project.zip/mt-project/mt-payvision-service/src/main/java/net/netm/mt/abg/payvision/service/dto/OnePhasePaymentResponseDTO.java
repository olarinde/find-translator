package net.netm.mt.abg.payvision.service.dto;

import java.io.Serializable;

public class OnePhasePaymentResponseDTO extends AbstractResponseDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 399530906206689315L;

	

}
