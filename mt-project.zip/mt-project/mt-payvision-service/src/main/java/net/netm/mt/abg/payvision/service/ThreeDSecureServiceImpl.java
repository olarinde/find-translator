/**
 *
 */
package net.netm.mt.abg.payvision.service;

import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import javax.xml.namespace.QName;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.interceptor.LoggingInInterceptor;
import org.apache.cxf.interceptor.LoggingOutInterceptor;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.transports.http.configuration.ProxyServerType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.payvision.gateway.ArrayOfCdcEntryItem;
import com.payvision.gateway.CdcEntry;
import com.payvision.gateway.CdcEntryItem;
import com.payvision.gateway.EnrollmentResult;
import com.payvision.gateway.ThreeDSecureOperations;
import com.payvision.gateway.ThreeDSecureOperationsHttpPost;
import com.payvision.gateway.ThreeDSecureOperationsSoap;

import net.netm.mt.abg.payvision.service.dto.PaymentBookingRequestDTO;
import net.netm.mt.abg.payvision.service.dto.PaymentBookingResponseDTO;
import net.netm.mt.abg.payvision.service.dto.PreparePaymentRequestDTO;
import net.netm.mt.abg.payvision.service.dto.PreparePaymentResponseDTO;

/**
 * @author larinde
 *
 */
public class ThreeDSecureServiceImpl implements ThreeDSecureService {

	private Logger logger = LoggerFactory.getLogger(this.getClass());
	private String proxyHost = "proxy.net-m.de";
	private int proxyPort = 3128;
//	private String proxyHost = "localhost";
//	private int proxyPort = 4040;
	private long timeOut = 60000;
//	private String threeDWsdlFile = "wsdl/ThreeDSecureOperations.asmx";
//    private static final QName SERVICE_NAME = new QName("http://payvision.com/gateway/", "ThreeDSecureOperations");

	@Override
	public PreparePaymentResponseDTO checkEnrollment(PreparePaymentRequestDTO request) {
		logger.debug("--- start checkEnrollment(PreparePaymentRequestDTO request) ---");

		HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
		httpClientPolicy.setConnectionTimeout(timeOut);
		httpClientPolicy.setReceiveTimeout(timeOut);
		httpClientPolicy.setProxyServer(proxyHost);
		httpClientPolicy.setProxyServerPort(proxyPort);
		httpClientPolicy.setProxyServerType(ProxyServerType.HTTP);

        ThreeDSecureOperations service = new ThreeDSecureOperations();
		ThreeDSecureOperationsHttpPost port = service.getThreeDSecureOperationsHttpPost();

		ThreeDSecureOperationsSoap threeDSSoap = service.getThreeDSecureOperationsSoap();

//        Client client = ClientProxy.getClient(port);
        Client client = ClientProxy.getClient(threeDSSoap);
        client.getInInterceptors().add(new LoggingInInterceptor());
        client.getOutInterceptors().add(new LoggingOutInterceptor());

		HTTPConduit httpConduit = (HTTPConduit) client.getConduit();
		httpConduit.setClient(httpClientPolicy);

		logger.debug(" ------- Endpoint: {} ------- ", client.getEndpoint().getEndpointInfo().getAddress());


		String currencyId = "978";
		String memberId = "2413";
		String trackingMemberCode = "test_".concat(String.valueOf(System.currentTimeMillis()));
		String memberGuid = "D68871F6-B161-4C1A-88BC-763271EB282E";

		String cardExpiryMonth = request.getCcExpireDate().split("-").clone()[0];
		String cardExpiryYear = request.getCcExpireDate().split("-").clone()[1];
//		EnrollmentResult enrollRst = port.checkEnrollment(memberId, memberGuid, request.getGrossAmount(),
//				currencyId, trackingMemberCode,
//				request.getAccountNumber(), request.getAccountOwnerLastname(),
//				cardExpiryMonth, cardExpiryYear);

		EnrollmentResult enrollRst = threeDSSoap.checkEnrollment(Integer.parseInt(memberId), memberGuid, new BigDecimal(request.getGrossAmount()), Integer.parseInt(currencyId), trackingMemberCode, request.getAccountNumber(), request.getAccountOwnerLastname(), Short.parseShort(cardExpiryMonth), Short.parseShort(cardExpiryYear));


//		CheckEnrollment checkEnrollment = new CheckEnrollment();
//		checkEnrollment.setMemberId(Integer.parseInt(memberId));
//		checkEnrollment.setMemberGuid(memberGuid);
//		checkEnrollment.setAmount(new BigDecimal(request.getGrossAmount()));
//		checkEnrollment.setCurrencyId(Integer.parseInt(currencyId));
//		checkEnrollment.setTrackingMemberCode(trackingMemberCode);
//		checkEnrollment.setCardNumber(request.getAccountNumber());
//		checkEnrollment.setCardHolder(request.getAccountOwnerLastname());
//		checkEnrollment.setCardExpiryMonth(Short.parseShort(cardExpiryMonth));
//		checkEnrollment.setCardExpiryYear(Short.parseShort(cardExpiryYear));





		PreparePaymentResponseDTO responseDTO = new PreparePaymentResponseDTO();

		String merchantPluginResult = "";

		if (String.valueOf(enrollRst.getResult()).equals("0")) {

		}

		responseDTO.setStatusCode(String.valueOf(enrollRst.getResult()));
		List<CdcEntry> cdcEntries = enrollRst.getCdc().getCdcEntry();

		for (CdcEntry cdcEntry : cdcEntries) {
			ArrayOfCdcEntryItem item =  cdcEntry.getItems();
			for (CdcEntryItem _itm : item.getCdcEntryItem()) {
				System.out.println("Key = " + _itm.getKey() + " Value = " + _itm.getValue());
				if (_itm.getKey().equals("MerchantPluginResult") ) {
					merchantPluginResult = _itm.getValue();
				}
			}
		}

		logger.debug("--- end checkEnrollment(PreparePaymentRequestDTO request) ---");
		return responseDTO;
	}

	@Override
	public PaymentBookingResponseDTO paymentUsingIntegratedMPI(PaymentBookingRequestDTO request) {
		// TODO Auto-generated method stub
		return null;
	}

}
