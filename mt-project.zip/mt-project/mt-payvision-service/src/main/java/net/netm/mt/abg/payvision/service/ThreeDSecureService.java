/**
 * 
 */
package net.netm.mt.abg.payvision.service;

import net.netm.mt.abg.payvision.service.dto.PaymentBookingRequestDTO;
import net.netm.mt.abg.payvision.service.dto.PaymentBookingResponseDTO;
import net.netm.mt.abg.payvision.service.dto.PreparePaymentRequestDTO;
import net.netm.mt.abg.payvision.service.dto.PreparePaymentResponseDTO;

/**
 * @author larinde
 * 
 */
public interface ThreeDSecureService {
	public PreparePaymentResponseDTO checkEnrollment(PreparePaymentRequestDTO request);

	public PaymentBookingResponseDTO paymentUsingIntegratedMPI(PaymentBookingRequestDTO request);
}
