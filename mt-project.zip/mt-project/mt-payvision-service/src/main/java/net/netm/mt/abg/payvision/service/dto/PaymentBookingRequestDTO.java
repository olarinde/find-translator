/**
 * 
 */
package net.netm.mt.abg.payvision.service.dto;

import java.io.Serializable;

/**
 * @author larinde
 * 
 */
public class PaymentBookingRequestDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -3153599422284496055L;
	public final String REQUEST_TYPE = "PaymentBooking"; // request-type=paymentBooking
	private String username;
	private String password;
	private String requestID;
	private String serviceType;
	private String transactionID;
	private String cvv;
	private String replypath;
	private String paymentType;
	private String version;
	// interim status
	private String code;

	/**
	 * Constructor
	 * 
	 */

	public PaymentBookingRequestDTO() {
		super();
	}

	/**
	 * Constructor
	 * 
	 * @param requestType
	 * @param username
	 * @param password
	 * @param requestId
	 * @param serviceType
	 * @param transactionId
	 * @param cvv
	 * @param replypath
	 */
	public PaymentBookingRequestDTO(String username, String password, String requestID, String serviceType, String transactionID, String cvv, String replypath) {
		super();
		this.username = username;
		this.password = password;
		this.requestID = requestID;
		this.serviceType = serviceType;
		this.transactionID = transactionID;
		this.cvv = cvv;
		this.replypath = replypath;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public String getReplypath() {
		return replypath;
	}

	public void setReplypath(String replypath) {
		this.replypath = replypath;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	/**
	 * helper method for building query string
	 * 
	 * @return
	 */
	public String toQuery() {
		return "Username=" + username + "&Password=" + password + "&RequestID=" + requestID + "&ServiceType=" + serviceType + "&PaymentType=" + paymentType + "&TransactionID=" + transactionID + "&CVV=" + cvv + "&replypath=" + replypath;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	@Override
	public String toString() {
		return "PaymentBookingRequestDTO [requestType=" + REQUEST_TYPE + ", username=" + username + ", password=" + password + ", requestID=" + requestID + ", serviceType=" + serviceType + ", transactionID=" + transactionID + ", cvv=" + cvv + ", replypath=" + replypath + ", paymentType="
				+ paymentType + ", version=" + version + ", code=" + code + "]";
	}

	/**
	 * @return the requestID
	 */
	public String getRequestID() {
		return requestID;
	}

	/**
	 * @param requestID the requestID to set
	 */
	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	/**
	 * @return the transactionID
	 */
	public String getTransactionID() {
		return transactionID;
	}

	/**
	 * @param transactionID the transactionID to set
	 */
	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}
	
	

}
