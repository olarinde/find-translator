/**
 * 
 */
package net.netm.mt.abg.payvision.service.dto;

import java.io.Serializable;

/**
 * @author larinde
 * 
 */
public class PaymentBookingResponseDTO extends AbstractResponseDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8776605653640082295L;

	public PaymentBookingResponseDTO() {
		super();
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	@Override
	public String toString() {
		return "PaymentBookingResponseDTO [transactiontype=" + transactiontype + ", reasonCode=" + reasonCode + ", reasonText=" + reasonText + ", statusCode=" + statusCode + ", statusText="
				+ statusText + ", requestID=" + requestID + ", transactionID=" + transactionID + "]";
	}

}
