/**
 * 
 */
package net.netm.mt.abg.payvision.service.util;

import java.io.PrintWriter;

import org.apache.cxf.interceptor.LoggingOutInterceptor;

/**
 *
 * @author:  Olarinde Ajai
 * @email:   olarinde.aja@net-m.de
 * @created: Sep 8, 2010 4:42:41 PM 
 */

public class ABGLoggingOutInterceptor extends LoggingOutInterceptor {

	/**
	 * 
	 */
	public ABGLoggingOutInterceptor() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param phase
	 */
	public ABGLoggingOutInterceptor(String phase) {
		super(phase);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param lim
	 */
	public ABGLoggingOutInterceptor(int lim) {
		super(lim);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param w
	 */
	public ABGLoggingOutInterceptor(PrintWriter w) {
		super(w);
		// TODO Auto-generated constructor stub
	}

}
