This is simply a placeholder so the "lib" directory exists
in CVS.  If you'd like to drop JARs in this directory 
(rather than using pom.xml), they will be included in the 
compilation and packaging of this project.
