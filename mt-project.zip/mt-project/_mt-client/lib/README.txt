If you're using Maven 2's Ant Tasks for more than one project, delete this 
directory and move the maven-ant-tasks-2.x.jar to $ANT_HOME/lib. After
doing this, you can remove the taskdef in build.xml.