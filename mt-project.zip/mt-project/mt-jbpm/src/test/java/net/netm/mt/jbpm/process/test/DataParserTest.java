package net.netm.mt.jbpm.process.test;

import org.jbpm.api.Configuration;
import org.jbpm.api.ProcessInstance;
import org.jbpm.api.job.Job;
import org.jbpm.test.JbpmTestCase;


public class DataParserTest extends JbpmTestCase {

	private static final String PROCESSS_ID = "DP";
	private String deploymentId; 
	private final String jpdlFile = "process/test.jpdl.xml"; 

//	@BeforeClass
//	protected void setUpBeforeClass() throws Exception {
//		processEngine = new Configuration().setResource("jbpm.cfg.xml").buildProcessEngine();
//	}

	protected void setUp() throws Exception {
		super.setUp();
		processEngine = new Configuration().setResource("jbpm.cfg.xml").buildProcessEngine();
		deploymentId =  repositoryService.createDeployment().addResourceFromClasspath(jpdlFile).deploy();
	}

	protected void tearDown() throws Exception {
		repositoryService.deleteDeploymentCascade(deploymentId);
		super.tearDown();
	}

	public void testLoadData() throws Exception {
		ProcessInstance processInstance = executionService.startProcessInstanceByKey(PROCESSS_ID); 
		String procInstId = processInstance.getId();
		assertEquals("ended", processInstance.getState());
//		System.out.println(processInstance.getState());
		
		Job job = managementService.createJobQuery().processInstanceId(procInstId).uniqueResult();
//		managementService.executeJob(job.getId());
		assertNull(job);
		

//		assertNull(executionService.findProcessInstanceById(procInstId));
	}

}
