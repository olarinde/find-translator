/**
 * 
 */
package net.netm.mt.shop.abg.payvision.dto;

/**
 * @author larinde
 * 
 */
public class QueryInfoResponseDTO extends AbstractResponseDTO {

	private String description;
	private String operatorID;
	private String paymentOperatorID;
	private String customerID;
	private String transactionStatusCode;
	private String transactionStatusText;
	private String subscriptions;
	private String number;
	private String subscription;
	private String subscriptionID;
	private String subscriptionStatusCode;
	private String subscriptionStatusText;
	private String serviceID;
	private String serviceType;
	private String subscriptionFee;
	private String itemFee;
	private String currency;
	private String vat;
	private String startTimestamp;
	private String lastOrderTimestamp;
	private String closedTimestamp;
	private String endTimestamp;

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description
	 *            the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the operatorID
	 */
	public String getOperatorID() {
		return operatorID;
	}

	/**
	 * @param operatorID
	 *            the operatorID to set
	 */
	public void setOperatorID(String operatorID) {
		this.operatorID = operatorID;
	}

	/**
	 * @return the paymentOperatorID
	 */
	public String getPaymentOperatorID() {
		return paymentOperatorID;
	}

	/**
	 * @param paymentOperatorID
	 *            the paymentOperatorID to set
	 */
	public void setPaymentOperatorID(String paymentOperatorID) {
		this.paymentOperatorID = paymentOperatorID;
	}

	/**
	 * @return the customerID
	 */
	public String getCustomerID() {
		return customerID;
	}

	/**
	 * @param customerID
	 *            the customerID to set
	 */
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}

	/**
	 * @return the transactionStatusCode
	 */
	public String getTransactionStatusCode() {
		return transactionStatusCode;
	}

	/**
	 * @param transactionStatusCode
	 *            the transactionStatusCode to set
	 */
	public void setTransactionStatusCode(String transactionStatusCode) {
		this.transactionStatusCode = transactionStatusCode;
	}

	/**
	 * @return the transactionStatusText
	 */
	public String getTransactionStatusText() {
		return transactionStatusText;
	}

	/**
	 * @param transactionStatusText
	 *            the transactionStatusText to set
	 */
	public void setTransactionStatusText(String transactionStatusText) {
		this.transactionStatusText = transactionStatusText;
	}

	/**
	 * @return the subscriptions
	 */
	public String getSubscriptions() {
		return subscriptions;
	}

	/**
	 * @param subscriptions
	 *            the subscriptions to set
	 */
	public void setSubscriptions(String subscriptions) {
		this.subscriptions = subscriptions;
	}

	/**
	 * @return the number
	 */
	public String getNumber() {
		return number;
	}

	/**
	 * @param number
	 *            the number to set
	 */
	public void setNumber(String number) {
		this.number = number;
	}

	/**
	 * @return the subscription
	 */
	public String getSubscription() {
		return subscription;
	}

	/**
	 * @param subscription
	 *            the subscription to set
	 */
	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	/**
	 * @return the subscriptionID
	 */
	public String getSubscriptionID() {
		return subscriptionID;
	}

	/**
	 * @param subscriptionID
	 *            the subscriptionID to set
	 */
	public void setSubscriptionID(String subscriptionID) {
		this.subscriptionID = subscriptionID;
	}

	/**
	 * @return the subscriptionStatusCode
	 */
	public String getSubscriptionStatusCode() {
		return subscriptionStatusCode;
	}

	/**
	 * @param subscriptionStatusCode
	 *            the subscriptionStatusCode to set
	 */
	public void setSubscriptionStatusCode(String subscriptionStatusCode) {
		this.subscriptionStatusCode = subscriptionStatusCode;
	}

	/**
	 * @return the subscriptionStatusText
	 */
	public String getSubscriptionStatusText() {
		return subscriptionStatusText;
	}

	/**
	 * @param subscriptionStatusText
	 *            the subscriptionStatusText to set
	 */
	public void setSubscriptionStatusText(String subscriptionStatusText) {
		this.subscriptionStatusText = subscriptionStatusText;
	}

	/**
	 * @return the serviceID
	 */
	public String getServiceID() {
		return serviceID;
	}

	/**
	 * @param serviceID
	 *            the serviceID to set
	 */
	public void setServiceID(String serviceID) {
		this.serviceID = serviceID;
	}

	/**
	 * @return the serviceType
	 */
	public String getServiceType() {
		return serviceType;
	}

	/**
	 * @param serviceType
	 *            the serviceType to set
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	/**
	 * @return the subscriptionFee
	 */
	public String getSubscriptionFee() {
		return subscriptionFee;
	}

	/**
	 * @param subscriptionFee
	 *            the subscriptionFee to set
	 */
	public void setSubscriptionFee(String subscriptionFee) {
		this.subscriptionFee = subscriptionFee;
	}

	/**
	 * @return the itemFee
	 */
	public String getItemFee() {
		return itemFee;
	}

	/**
	 * @param itemFee
	 *            the itemFee to set
	 */
	public void setItemFee(String itemFee) {
		this.itemFee = itemFee;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency
	 *            the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the vat
	 */
	public String getVat() {
		return vat;
	}

	/**
	 * @param vat
	 *            the vat to set
	 */
	public void setVat(String vat) {
		this.vat = vat;
	}

	/**
	 * @return the startTimestamp
	 */
	public String getStartTimestamp() {
		return startTimestamp;
	}

	/**
	 * @param startTimestamp
	 *            the startTimestamp to set
	 */
	public void setStartTimestamp(String startTimestamp) {
		this.startTimestamp = startTimestamp;
	}

	/**
	 * @return the lastOrderTimestamp
	 */
	public String getLastOrderTimestamp() {
		return lastOrderTimestamp;
	}

	/**
	 * @param lastOrderTimestamp
	 *            the lastOrderTimestamp to set
	 */
	public void setLastOrderTimestamp(String lastOrderTimestamp) {
		this.lastOrderTimestamp = lastOrderTimestamp;
	}

	/**
	 * @return the closedTimestamp
	 */
	public String getClosedTimestamp() {
		return closedTimestamp;
	}

	/**
	 * @param closedTimestamp
	 *            the closedTimestamp to set
	 */
	public void setClosedTimestamp(String closedTimestamp) {
		this.closedTimestamp = closedTimestamp;
	}

	/**
	 * @return the endTimestamp
	 */
	public String getEndTimestamp() {
		return endTimestamp;
	}

	/**
	 * @param endTimestamp
	 *            the endTimestamp to set
	 */
	public void setEndTimestamp(String endTimestamp) {
		this.endTimestamp = endTimestamp;
	}

	@Override
	public String toString() {
		return "QueryInfoResponseDTO [description=" + description + ", operatorID=" + operatorID + ", paymentOperatorID=" + paymentOperatorID + ", customerID=" + customerID + ", transactionStatusCode=" + transactionStatusCode + ", transactionStatusText=" + transactionStatusText + ", subscriptions="
				+ subscriptions + ", number=" + number + ", subscription=" + subscription + ", subscriptionID=" + subscriptionID + ", subscriptionStatusCode=" + subscriptionStatusCode + ", subscriptionStatusText=" + subscriptionStatusText + ", serviceID=" + serviceID + ", serviceType="
				+ serviceType + ", subscriptionFee=" + subscriptionFee + ", itemFee=" + itemFee + ", currency=" + currency + ", vat=" + vat + ", startTimestamp=" + startTimestamp + ", lastOrderTimestamp=" + lastOrderTimestamp + ", closedTimestamp=" + closedTimestamp + ", endTimestamp="
				+ endTimestamp + ", statusCode=" + statusCode + ", statusText=" + statusText + ", requestID=" + requestID + ", transactionID=" + transactionID + "]";
	}

}
