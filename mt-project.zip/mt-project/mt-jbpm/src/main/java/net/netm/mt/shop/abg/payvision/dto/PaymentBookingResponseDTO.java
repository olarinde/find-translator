/**
 * 
 */
package net.netm.mt.shop.abg.payvision.dto;

import java.io.Serializable;

/**
 * @author larinde
 * 
 */
public class PaymentBookingResponseDTO extends AbstractResponseDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8776605653640082295L;

	private String transactiontype;
	private String reasonCode;
	private String reasonText;

	public PaymentBookingResponseDTO() {
		super();
	}

	public String getTransactiontype() {
		return transactiontype;
	}

	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getReasonText() {
		return reasonText;
	}

	public void setReasonText(String reasonText) {
		this.reasonText = reasonText;
	}

	@Override
	public String toString() {
		return "PaymentBookingResponseDTO [transactiontype=" + transactiontype + ", reasonCode=" + reasonCode + ", reasonText=" + reasonText + ", statusCode=" + statusCode + ", statusText=" + statusText + ", requestID=" + requestID + ", transactionID=" + transactionID + "]";
	}

	

}
