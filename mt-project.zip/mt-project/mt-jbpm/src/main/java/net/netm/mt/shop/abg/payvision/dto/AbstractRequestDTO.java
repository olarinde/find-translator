package net.netm.mt.shop.abg.payvision.dto;

public class AbstractRequestDTO {

	protected String version; // Version=5.0
	protected String username; // Username=u00000d6
	protected String password; // Password=QxpE1ooM
	protected String requestId;// RequestID=1156
	protected String serviceType; // ServiceType=web
	protected String paymentType; // PaymentType=otp
	protected String serviceId;// ServiceID=abg_cc_pv_3ds
	protected String m2m;// M2M=1
	protected String category;// Category=11
	protected String remoteIp; // RemoteIP=95.112.85.34

	public AbstractRequestDTO() {
		super();
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getServiceId() {
		return serviceId;
	}

	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}

	public String getM2m() {
		return m2m;
	}

	public void setM2m(String m2m) {
		this.m2m = m2m;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getRemoteIp() {
		return remoteIp;
	}

	public void setRemoteIp(String remoteIp) {
		this.remoteIp = remoteIp;
	}

}