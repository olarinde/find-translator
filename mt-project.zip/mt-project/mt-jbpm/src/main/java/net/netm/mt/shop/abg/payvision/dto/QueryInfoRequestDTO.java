/**
 * 
 */
package net.netm.mt.shop.abg.payvision.dto;

import java.io.Serializable;

/**
 * @author larinde
 * 
 */
public class QueryInfoRequestDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String requestType;
	private String version;
	private String username;
	private String password;
	private String requestID;
	private String transactionID;

	public QueryInfoRequestDTO() {
		super();
	}

	/**
	 * constructor
	 * 
	 * @param requestType
	 * @param version
	 * @param username
	 * @param password
	 * @param requestID
	 * @param transactionID
	 */
	public QueryInfoRequestDTO(String requestType, String version, String username, String password, String requestID, String transactionID) {
		super();
		this.requestType = requestType;
		this.version = version;
		this.username = username;
		this.password = password;
		this.requestID = requestID;
		this.transactionID = transactionID;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	@Override
	public String toString() {
		return "QueryInfoRequestDTO [requestType=" + requestType + ", version=" + version + ", username=" + username + ", password=" + password + ", requestID=" + requestID + ", transactionID=" + transactionID + "]";
	}

}
