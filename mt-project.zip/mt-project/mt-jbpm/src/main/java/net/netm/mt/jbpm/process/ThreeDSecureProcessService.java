package net.netm.mt.jbpm.process;

import net.netm.mt.jbpm.abg.payvision.exception.BusinessException;




public interface ThreeDSecureProcessService {

	public abstract String preparePayment(String requestDTO) throws BusinessException;

	public abstract String paymentBooking(String pymtBookingReqDTO) throws BusinessException;
	
	public abstract String queryInfo(String requestDTO);

}