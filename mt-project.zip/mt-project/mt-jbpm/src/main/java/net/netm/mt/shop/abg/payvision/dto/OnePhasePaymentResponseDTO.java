package net.netm.mt.shop.abg.payvision.dto;

public class OnePhasePaymentResponseDTO extends AbstractResponseDTO {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
