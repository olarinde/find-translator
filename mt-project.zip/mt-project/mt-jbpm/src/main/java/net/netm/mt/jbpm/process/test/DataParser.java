/**
 * 
 */
package net.netm.mt.jbpm.process.test;

import java.io.Serializable;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author larinde
 *
 */
public class DataParser implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5987456216050439983L;
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	public void loadData() {
		logger.info("\n============\nloading data...\n============\n");
	}

	public void updateData() {
		logger.info("\n============\nupdating data...\n============\n");
		
	}
}
