/**
 * 
 */
package net.netm.mt.shop.abg.payvision.dto;

import java.io.Serializable;

/**
 * @author larinde
 * 
 */
public class PreparePaymentResponseDTO extends AbstractResponseDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8776605653640082295L;

	private String transactiontype;
	private String consumerID;
	private long validityPeriod;
	private String paymentUrl;

	// private String termUrl;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	public String getTransactiontype() {
		return transactiontype;
	}

	public void setTransactiontype(String transactiontype) {
		this.transactiontype = transactiontype;
	}

	public String getRequestID() {
		return requestID;
	}

	public void setRequestID(String requestID) {
		this.requestID = requestID;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(String transactionID) {
		this.transactionID = transactionID;
	}

	public String getConsumerID() {
		return consumerID;
	}

	public void setConsumerID(String consumerID) {
		this.consumerID = consumerID;
	}

	public long getValidityPeriod() {
		return validityPeriod;
	}

	public void setValidityPeriod(long validityPeriod) {
		this.validityPeriod = validityPeriod;
	}

	public String getPaymentUrl() {
		return paymentUrl;
	}

	public void setPaymentUrl(String paymentUrl) {
		this.paymentUrl = paymentUrl;
	}

	@Override
	public String toString() {
		return "PreparePaymentResponseDTO [statusCode=" + statusCode + ", statusText=" + statusText + ", transactiontype=" + transactiontype + ", requestID=" + requestID + ", transactionID=" + transactionID + ", consumerID=" + consumerID + ", validityPeriod=" + validityPeriod + ", paymentUrl="
				+ paymentUrl + "]";
	}

}
