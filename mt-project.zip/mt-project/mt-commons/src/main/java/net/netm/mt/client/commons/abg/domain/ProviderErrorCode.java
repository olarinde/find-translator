package net.netm.mt.client.commons.abg.domain;

public class ProviderErrorCode {

}
