package net.netm.mt.client.commons.abg.domain;

public class ReasonTextMapping {

	private String reasonCode;
	private String reasonText;

	public ReasonTextMapping() {
		super();
	}

	public ReasonTextMapping(String reasonCode, String reasonText) {
		super();
		this.reasonCode = reasonCode;
		this.reasonText = reasonText;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getReasonText() {
		return reasonText;
	}

	public void setReasonText(String reasonText) {
		this.reasonText = reasonText;
	}

}
