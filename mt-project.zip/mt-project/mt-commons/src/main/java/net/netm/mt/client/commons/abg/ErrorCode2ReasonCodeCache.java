package net.netm.mt.client.commons.abg;

import java.util.HashMap;
import java.util.Map;

public class ErrorCode2ReasonCodeCache {

	private static ErrorCode2ReasonCodeCache instance = null;

	private String errorCodeFile = "ABGErrorCode2ReasonCodeMap.xml";

	private Map<String, RequestTracking> clientTrackings = new HashMap<String, RequestTracking>();

	public synchronized static ErrorCode2ReasonCodeCache getInstance() {
		if (instance == null) {
			instance = new ErrorCode2ReasonCodeCache();
		}
		return instance;
	}

	private ErrorCode2ReasonCodeCache() {
		init();
	}

	private void init() {

	}

	public Map<String, RequestTracking> getClientTrackings() {
		return clientTrackings;
	}

	public void addNewClient(String clientId, RequestTracking requestTracking) {
		clientTrackings.put(clientId, requestTracking);
	}

	public RequestTracking getClientRequestTracking(String clientId) {
		return clientTrackings.get(clientId);
	}

}
