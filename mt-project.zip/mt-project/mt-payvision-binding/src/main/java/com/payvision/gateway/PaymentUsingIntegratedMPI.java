
package com.payvision.gateway;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="memberId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="memberGuid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="countryId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="trackingMemberCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cardCvv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="merchantAccountType" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="dynamicDescriptor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="avsAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="avsZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="enrollmentId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="enrollmentTrackingMemberCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="payerAuthenticationResponse" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "memberId",
    "memberGuid",
    "countryId",
    "trackingMemberCode",
    "cardCvv",
    "merchantAccountType",
    "dynamicDescriptor",
    "avsAddress",
    "avsZip",
    "enrollmentId",
    "enrollmentTrackingMemberCode",
    "payerAuthenticationResponse"
})
@XmlRootElement(name = "PaymentUsingIntegratedMPI")
public class PaymentUsingIntegratedMPI {

    protected int memberId;
    protected String memberGuid;
    protected int countryId;
    protected String trackingMemberCode;
    protected String cardCvv;
    protected int merchantAccountType;
    protected String dynamicDescriptor;
    protected String avsAddress;
    protected String avsZip;
    protected int enrollmentId;
    protected String enrollmentTrackingMemberCode;
    protected String payerAuthenticationResponse;

    /**
     * Gets the value of the memberId property.
     * 
     */
    public int getMemberId() {
        return memberId;
    }

    /**
     * Sets the value of the memberId property.
     * 
     */
    public void setMemberId(int value) {
        this.memberId = value;
    }

    /**
     * Gets the value of the memberGuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberGuid() {
        return memberGuid;
    }

    /**
     * Sets the value of the memberGuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberGuid(String value) {
        this.memberGuid = value;
    }

    /**
     * Gets the value of the countryId property.
     * 
     */
    public int getCountryId() {
        return countryId;
    }

    /**
     * Sets the value of the countryId property.
     * 
     */
    public void setCountryId(int value) {
        this.countryId = value;
    }

    /**
     * Gets the value of the trackingMemberCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingMemberCode() {
        return trackingMemberCode;
    }

    /**
     * Sets the value of the trackingMemberCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingMemberCode(String value) {
        this.trackingMemberCode = value;
    }

    /**
     * Gets the value of the cardCvv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardCvv() {
        return cardCvv;
    }

    /**
     * Sets the value of the cardCvv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardCvv(String value) {
        this.cardCvv = value;
    }

    /**
     * Gets the value of the merchantAccountType property.
     * 
     */
    public int getMerchantAccountType() {
        return merchantAccountType;
    }

    /**
     * Sets the value of the merchantAccountType property.
     * 
     */
    public void setMerchantAccountType(int value) {
        this.merchantAccountType = value;
    }

    /**
     * Gets the value of the dynamicDescriptor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDynamicDescriptor() {
        return dynamicDescriptor;
    }

    /**
     * Sets the value of the dynamicDescriptor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDynamicDescriptor(String value) {
        this.dynamicDescriptor = value;
    }

    /**
     * Gets the value of the avsAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvsAddress() {
        return avsAddress;
    }

    /**
     * Sets the value of the avsAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvsAddress(String value) {
        this.avsAddress = value;
    }

    /**
     * Gets the value of the avsZip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvsZip() {
        return avsZip;
    }

    /**
     * Sets the value of the avsZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvsZip(String value) {
        this.avsZip = value;
    }

    /**
     * Gets the value of the enrollmentId property.
     * 
     */
    public int getEnrollmentId() {
        return enrollmentId;
    }

    /**
     * Sets the value of the enrollmentId property.
     * 
     */
    public void setEnrollmentId(int value) {
        this.enrollmentId = value;
    }

    /**
     * Gets the value of the enrollmentTrackingMemberCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnrollmentTrackingMemberCode() {
        return enrollmentTrackingMemberCode;
    }

    /**
     * Sets the value of the enrollmentTrackingMemberCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnrollmentTrackingMemberCode(String value) {
        this.enrollmentTrackingMemberCode = value;
    }

    /**
     * Gets the value of the payerAuthenticationResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPayerAuthenticationResponse() {
        return payerAuthenticationResponse;
    }

    /**
     * Sets the value of the payerAuthenticationResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPayerAuthenticationResponse(String value) {
        this.payerAuthenticationResponse = value;
    }

}
