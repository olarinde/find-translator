
package com.payvision.gateway;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="RetrieveTransactionResultResult" type="{http://payvision.com/gateway/}TransactionResult" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "retrieveTransactionResultResult"
})
@XmlRootElement(name = "RetrieveTransactionResultResponse")
public class RetrieveTransactionResultResponse {

    @XmlElement(name = "RetrieveTransactionResultResult")
    protected TransactionResult retrieveTransactionResultResult;

    /**
     * Gets the value of the retrieveTransactionResultResult property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionResult }
     *     
     */
    public TransactionResult getRetrieveTransactionResultResult() {
        return retrieveTransactionResultResult;
    }

    /**
     * Sets the value of the retrieveTransactionResultResult property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionResult }
     *     
     */
    public void setRetrieveTransactionResultResult(TransactionResult value) {
        this.retrieveTransactionResultResult = value;
    }

}
