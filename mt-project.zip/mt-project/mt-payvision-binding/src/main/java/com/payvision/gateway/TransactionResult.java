
package com.payvision.gateway;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for TransactionResult complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TransactionResult">
 *   &lt;complexContent>
 *     &lt;extension base="{http://payvision.com/gateway/}BaseEntity">
 *       &lt;sequence>
 *         &lt;element name="Result" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Message" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TrackingMemberCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TransactionId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="TransactionGuid" type="{http://microsoft.com/wsdl/types/}guid"/>
 *         &lt;element name="TransactionDateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Cdc" type="{http://payvision.com/gateway/}ArrayOfCdcEntry" minOccurs="0"/>
 *         &lt;element name="Recovered" type="{http://www.w3.org/2001/XMLSchema}boolean" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionResult", propOrder = {
    "result",
    "message",
    "trackingMemberCode",
    "transactionId",
    "transactionGuid",
    "transactionDateTime",
    "cdc",
    "recovered"
})
public class TransactionResult
    extends BaseEntity
{

    @XmlElement(name = "Result")
    protected int result;
    @XmlElement(name = "Message")
    protected String message;
    @XmlElement(name = "TrackingMemberCode")
    protected String trackingMemberCode;
    @XmlElement(name = "TransactionId")
    protected int transactionId;
    @XmlElement(name = "TransactionGuid", required = true)
    protected String transactionGuid;
    @XmlElement(name = "TransactionDateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar transactionDateTime;
    @XmlElement(name = "Cdc")
    protected ArrayOfCdcEntry cdc;
    @XmlElement(name = "Recovered")
    protected Boolean recovered;

    /**
     * Gets the value of the result property.
     * 
     */
    public int getResult() {
        return result;
    }

    /**
     * Sets the value of the result property.
     * 
     */
    public void setResult(int value) {
        this.result = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the trackingMemberCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingMemberCode() {
        return trackingMemberCode;
    }

    /**
     * Sets the value of the trackingMemberCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingMemberCode(String value) {
        this.trackingMemberCode = value;
    }

    /**
     * Gets the value of the transactionId property.
     * 
     */
    public int getTransactionId() {
        return transactionId;
    }

    /**
     * Sets the value of the transactionId property.
     * 
     */
    public void setTransactionId(int value) {
        this.transactionId = value;
    }

    /**
     * Gets the value of the transactionGuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionGuid() {
        return transactionGuid;
    }

    /**
     * Sets the value of the transactionGuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionGuid(String value) {
        this.transactionGuid = value;
    }

    /**
     * Gets the value of the transactionDateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getTransactionDateTime() {
        return transactionDateTime;
    }

    /**
     * Sets the value of the transactionDateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setTransactionDateTime(XMLGregorianCalendar value) {
        this.transactionDateTime = value;
    }

    /**
     * Gets the value of the cdc property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfCdcEntry }
     *     
     */
    public ArrayOfCdcEntry getCdc() {
        return cdc;
    }

    /**
     * Sets the value of the cdc property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfCdcEntry }
     *     
     */
    public void setCdc(ArrayOfCdcEntry value) {
        this.cdc = value;
    }

    /**
     * Gets the value of the recovered property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isRecovered() {
        return recovered;
    }

    /**
     * Sets the value of the recovered property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setRecovered(Boolean value) {
        this.recovered = value;
    }

}
