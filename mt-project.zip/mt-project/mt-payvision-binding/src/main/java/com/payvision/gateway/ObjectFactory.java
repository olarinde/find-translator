
package com.payvision.gateway;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.payvision.gateway package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _TransactionResult_QNAME = new QName("http://payvision.com/gateway/", "TransactionResult");
    private final static QName _OriginatorHeader_QNAME = new QName("http://payvision.com/gateway/", "OriginatorHeader");
    private final static QName _EnrollmentResult_QNAME = new QName("http://payvision.com/gateway/", "EnrollmentResult");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.payvision.gateway
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link PaymentUsingIntegratedMPIResponse }
     * 
     */
    public PaymentUsingIntegratedMPIResponse createPaymentUsingIntegratedMPIResponse() {
        return new PaymentUsingIntegratedMPIResponse();
    }

    /**
     * Create an instance of {@link CdcEntryItem }
     * 
     */
    public CdcEntryItem createCdcEntryItem() {
        return new CdcEntryItem();
    }

    /**
     * Create an instance of {@link Authorize }
     * 
     */
    public Authorize createAuthorize() {
        return new Authorize();
    }

    /**
     * Create an instance of {@link CheckEnrollment }
     * 
     */
    public CheckEnrollment createCheckEnrollment() {
        return new CheckEnrollment();
    }

    /**
     * Create an instance of {@link PaymentUsingIntegratedMPI }
     * 
     */
    public PaymentUsingIntegratedMPI createPaymentUsingIntegratedMPI() {
        return new PaymentUsingIntegratedMPI();
    }

    /**
     * Create an instance of {@link AuthorizeUsingIntegratedMPI }
     * 
     */
    public AuthorizeUsingIntegratedMPI createAuthorizeUsingIntegratedMPI() {
        return new AuthorizeUsingIntegratedMPI();
    }

    /**
     * Create an instance of {@link ArrayOfCdcEntry }
     * 
     */
    public ArrayOfCdcEntry createArrayOfCdcEntry() {
        return new ArrayOfCdcEntry();
    }

    /**
     * Create an instance of {@link AuthorizeUsingIntegratedMPIResponse }
     * 
     */
    public AuthorizeUsingIntegratedMPIResponse createAuthorizeUsingIntegratedMPIResponse() {
        return new AuthorizeUsingIntegratedMPIResponse();
    }

    /**
     * Create an instance of {@link ArrayOfCdcEntryItem }
     * 
     */
    public ArrayOfCdcEntryItem createArrayOfCdcEntryItem() {
        return new ArrayOfCdcEntryItem();
    }

    /**
     * Create an instance of {@link EnrollmentResult }
     * 
     */
    public EnrollmentResult createEnrollmentResult() {
        return new EnrollmentResult();
    }

    /**
     * Create an instance of {@link CdcEntry }
     * 
     */
    public CdcEntry createCdcEntry() {
        return new CdcEntry();
    }

    /**
     * Create an instance of {@link Payment }
     * 
     */
    public Payment createPayment() {
        return new Payment();
    }

    /**
     * Create an instance of {@link CheckEnrollmentResponse }
     * 
     */
    public CheckEnrollmentResponse createCheckEnrollmentResponse() {
        return new CheckEnrollmentResponse();
    }

    /**
     * Create an instance of {@link TransactionResult }
     * 
     */
    public TransactionResult createTransactionResult() {
        return new TransactionResult();
    }

    /**
     * Create an instance of {@link AuthorizeResponse }
     * 
     */
    public AuthorizeResponse createAuthorizeResponse() {
        return new AuthorizeResponse();
    }

    /**
     * Create an instance of {@link OriginatorHeader }
     * 
     */
    public OriginatorHeader createOriginatorHeader() {
        return new OriginatorHeader();
    }

    /**
     * Create an instance of {@link PaymentResponse }
     * 
     */
    public PaymentResponse createPaymentResponse() {
        return new PaymentResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link TransactionResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://payvision.com/gateway/", name = "TransactionResult")
    public JAXBElement<TransactionResult> createTransactionResult(TransactionResult value) {
        return new JAXBElement<TransactionResult>(_TransactionResult_QNAME, TransactionResult.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OriginatorHeader }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://payvision.com/gateway/", name = "OriginatorHeader")
    public JAXBElement<OriginatorHeader> createOriginatorHeader(OriginatorHeader value) {
        return new JAXBElement<OriginatorHeader>(_OriginatorHeader_QNAME, OriginatorHeader.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EnrollmentResult }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://payvision.com/gateway/", name = "EnrollmentResult")
    public JAXBElement<EnrollmentResult> createEnrollmentResult(EnrollmentResult value) {
        return new JAXBElement<EnrollmentResult>(_EnrollmentResult_QNAME, EnrollmentResult.class, null, value);
    }

}
