
package com.payvision.gateway;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="memberId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="memberGuid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="countryId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="amount" type="{http://www.w3.org/2001/XMLSchema}decimal"/>
 *         &lt;element name="currencyId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="trackingMemberCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cardNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cardHolder" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cardExpiryMonth" type="{http://www.w3.org/2001/XMLSchema}unsignedByte"/>
 *         &lt;element name="cardExpiryYear" type="{http://www.w3.org/2001/XMLSchema}short"/>
 *         &lt;element name="cardCvv" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cardType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="issueNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="merchantAccountType" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="dynamicDescriptor" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="avsAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="avsZip" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="xid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="authenticationValue" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="authenticationIndicator" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "memberId",
    "memberGuid",
    "countryId",
    "amount",
    "currencyId",
    "trackingMemberCode",
    "cardNumber",
    "cardHolder",
    "cardExpiryMonth",
    "cardExpiryYear",
    "cardCvv",
    "cardType",
    "issueNumber",
    "merchantAccountType",
    "dynamicDescriptor",
    "avsAddress",
    "avsZip",
    "xid",
    "authenticationValue",
    "authenticationIndicator"
})
@XmlRootElement(name = "Authorize")
public class Authorize {

    protected int memberId;
    protected String memberGuid;
    protected int countryId;
    @XmlElement(required = true)
    protected BigDecimal amount;
    protected int currencyId;
    protected String trackingMemberCode;
    protected String cardNumber;
    protected String cardHolder;
    @XmlSchemaType(name = "unsignedByte")
    protected short cardExpiryMonth;
    protected short cardExpiryYear;
    protected String cardCvv;
    protected String cardType;
    protected String issueNumber;
    protected int merchantAccountType;
    protected String dynamicDescriptor;
    protected String avsAddress;
    protected String avsZip;
    protected String xid;
    protected String authenticationValue;
    protected String authenticationIndicator;

    /**
     * Gets the value of the memberId property.
     * 
     */
    public int getMemberId() {
        return memberId;
    }

    /**
     * Sets the value of the memberId property.
     * 
     */
    public void setMemberId(int value) {
        this.memberId = value;
    }

    /**
     * Gets the value of the memberGuid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMemberGuid() {
        return memberGuid;
    }

    /**
     * Sets the value of the memberGuid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMemberGuid(String value) {
        this.memberGuid = value;
    }

    /**
     * Gets the value of the countryId property.
     * 
     */
    public int getCountryId() {
        return countryId;
    }

    /**
     * Sets the value of the countryId property.
     * 
     */
    public void setCountryId(int value) {
        this.countryId = value;
    }

    /**
     * Gets the value of the amount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * Sets the value of the amount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setAmount(BigDecimal value) {
        this.amount = value;
    }

    /**
     * Gets the value of the currencyId property.
     * 
     */
    public int getCurrencyId() {
        return currencyId;
    }

    /**
     * Sets the value of the currencyId property.
     * 
     */
    public void setCurrencyId(int value) {
        this.currencyId = value;
    }

    /**
     * Gets the value of the trackingMemberCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingMemberCode() {
        return trackingMemberCode;
    }

    /**
     * Sets the value of the trackingMemberCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingMemberCode(String value) {
        this.trackingMemberCode = value;
    }

    /**
     * Gets the value of the cardNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardNumber() {
        return cardNumber;
    }

    /**
     * Sets the value of the cardNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardNumber(String value) {
        this.cardNumber = value;
    }

    /**
     * Gets the value of the cardHolder property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardHolder() {
        return cardHolder;
    }

    /**
     * Sets the value of the cardHolder property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardHolder(String value) {
        this.cardHolder = value;
    }

    /**
     * Gets the value of the cardExpiryMonth property.
     * 
     */
    public short getCardExpiryMonth() {
        return cardExpiryMonth;
    }

    /**
     * Sets the value of the cardExpiryMonth property.
     * 
     */
    public void setCardExpiryMonth(short value) {
        this.cardExpiryMonth = value;
    }

    /**
     * Gets the value of the cardExpiryYear property.
     * 
     */
    public short getCardExpiryYear() {
        return cardExpiryYear;
    }

    /**
     * Sets the value of the cardExpiryYear property.
     * 
     */
    public void setCardExpiryYear(short value) {
        this.cardExpiryYear = value;
    }

    /**
     * Gets the value of the cardCvv property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardCvv() {
        return cardCvv;
    }

    /**
     * Sets the value of the cardCvv property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardCvv(String value) {
        this.cardCvv = value;
    }

    /**
     * Gets the value of the cardType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCardType() {
        return cardType;
    }

    /**
     * Sets the value of the cardType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCardType(String value) {
        this.cardType = value;
    }

    /**
     * Gets the value of the issueNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssueNumber() {
        return issueNumber;
    }

    /**
     * Sets the value of the issueNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssueNumber(String value) {
        this.issueNumber = value;
    }

    /**
     * Gets the value of the merchantAccountType property.
     * 
     */
    public int getMerchantAccountType() {
        return merchantAccountType;
    }

    /**
     * Sets the value of the merchantAccountType property.
     * 
     */
    public void setMerchantAccountType(int value) {
        this.merchantAccountType = value;
    }

    /**
     * Gets the value of the dynamicDescriptor property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDynamicDescriptor() {
        return dynamicDescriptor;
    }

    /**
     * Sets the value of the dynamicDescriptor property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDynamicDescriptor(String value) {
        this.dynamicDescriptor = value;
    }

    /**
     * Gets the value of the avsAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvsAddress() {
        return avsAddress;
    }

    /**
     * Sets the value of the avsAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvsAddress(String value) {
        this.avsAddress = value;
    }

    /**
     * Gets the value of the avsZip property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvsZip() {
        return avsZip;
    }

    /**
     * Sets the value of the avsZip property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvsZip(String value) {
        this.avsZip = value;
    }

    /**
     * Gets the value of the xid property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXid() {
        return xid;
    }

    /**
     * Sets the value of the xid property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXid(String value) {
        this.xid = value;
    }

    /**
     * Gets the value of the authenticationValue property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthenticationValue() {
        return authenticationValue;
    }

    /**
     * Sets the value of the authenticationValue property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthenticationValue(String value) {
        this.authenticationValue = value;
    }

    /**
     * Gets the value of the authenticationIndicator property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAuthenticationIndicator() {
        return authenticationIndicator;
    }

    /**
     * Sets the value of the authenticationIndicator property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAuthenticationIndicator(String value) {
        this.authenticationIndicator = value;
    }

}
