@javax.xml.bind.annotation.XmlSchema(namespace = "http://payvision.com/gateway/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.payvision.gateway;
