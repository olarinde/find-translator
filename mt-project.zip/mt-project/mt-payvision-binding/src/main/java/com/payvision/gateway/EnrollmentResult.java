
package com.payvision.gateway;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for EnrollmentResult complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EnrollmentResult">
 *   &lt;complexContent>
 *     &lt;extension base="{http://payvision.com/gateway/}BaseEntity">
 *       &lt;sequence>
 *         &lt;element name="Result" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="Message" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="TrackingMemberCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="EnrollmentId" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="IssuerUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="PaymentAuthenticationRequest" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="DateTime" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="Cdc" type="{http://payvision.com/gateway/}ArrayOfCdcEntry" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/extension>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EnrollmentResult", propOrder = {
    "result",
    "message",
    "trackingMemberCode",
    "enrollmentId",
    "issuerUrl",
    "paymentAuthenticationRequest",
    "dateTime",
    "cdc"
})
public class EnrollmentResult
    extends BaseEntity
{

    @XmlElement(name = "Result")
    protected int result;
    @XmlElement(name = "Message")
    protected String message;
    @XmlElement(name = "TrackingMemberCode")
    protected String trackingMemberCode;
    @XmlElement(name = "EnrollmentId")
    protected int enrollmentId;
    @XmlElement(name = "IssuerUrl")
    protected String issuerUrl;
    @XmlElement(name = "PaymentAuthenticationRequest")
    protected String paymentAuthenticationRequest;
    @XmlElement(name = "DateTime", required = true)
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateTime;
    @XmlElement(name = "Cdc")
    protected ArrayOfCdcEntry cdc;

    /**
     * Gets the value of the result property.
     * 
     */
    public int getResult() {
        return result;
    }

    /**
     * Sets the value of the result property.
     * 
     */
    public void setResult(int value) {
        this.result = value;
    }

    /**
     * Gets the value of the message property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessage() {
        return message;
    }

    /**
     * Sets the value of the message property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessage(String value) {
        this.message = value;
    }

    /**
     * Gets the value of the trackingMemberCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingMemberCode() {
        return trackingMemberCode;
    }

    /**
     * Sets the value of the trackingMemberCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingMemberCode(String value) {
        this.trackingMemberCode = value;
    }

    /**
     * Gets the value of the enrollmentId property.
     * 
     */
    public int getEnrollmentId() {
        return enrollmentId;
    }

    /**
     * Sets the value of the enrollmentId property.
     * 
     */
    public void setEnrollmentId(int value) {
        this.enrollmentId = value;
    }

    /**
     * Gets the value of the issuerUrl property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getIssuerUrl() {
        return issuerUrl;
    }

    /**
     * Sets the value of the issuerUrl property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setIssuerUrl(String value) {
        this.issuerUrl = value;
    }

    /**
     * Gets the value of the paymentAuthenticationRequest property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getPaymentAuthenticationRequest() {
        return paymentAuthenticationRequest;
    }

    /**
     * Sets the value of the paymentAuthenticationRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setPaymentAuthenticationRequest(String value) {
        this.paymentAuthenticationRequest = value;
    }

    /**
     * Gets the value of the dateTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateTime() {
        return dateTime;
    }

    /**
     * Sets the value of the dateTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateTime(XMLGregorianCalendar value) {
        this.dateTime = value;
    }

    /**
     * Gets the value of the cdc property.
     * 
     * @return
     *     possible object is
     *     {@link ArrayOfCdcEntry }
     *     
     */
    public ArrayOfCdcEntry getCdc() {
        return cdc;
    }

    /**
     * Sets the value of the cdc property.
     * 
     * @param value
     *     allowed object is
     *     {@link ArrayOfCdcEntry }
     *     
     */
    public void setCdc(ArrayOfCdcEntry value) {
        this.cdc = value;
    }

}
