mvn generate-sources
mvn clean package install