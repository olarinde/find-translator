
package com.koweg.iam.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
    "name",
    "value",
    "assignmentOperation",
    "unassignmentOperation"
})
public class Value {

    @JsonProperty("name")
    private String name;
    @JsonProperty("value")
    private List<String> value = new ArrayList<String>();
    @JsonProperty("assignmentOperation")
    private String assignmentOperation;
    @JsonProperty("unassignmentOperation")
    private String unassignmentOperation;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public Value() {
    }

    /**
     * 
     * @param name
     * @param value
     * @param assignmentOperation
     * @param unassignmentOperation
     */
    public Value(String name, List<String> value, String assignmentOperation, String unassignmentOperation) {
        this.name = name;
        this.value = value;
        this.assignmentOperation = assignmentOperation;
        this.unassignmentOperation = unassignmentOperation;
    }

    /**
     * 
     * @return
     *     The name
     */
    @JsonProperty("name")
    public String getName() {
        return name;
    }

    /**
     * 
     * @param name
     *     The name
     */
    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 
     * @return
     *     The value
     */
    @JsonProperty("value")
    public List<String> getValue() {
        return value;
    }

    /**
     * 
     * @param value
     *     The value
     */
    @JsonProperty("value")
    public void setValue(List<String> value) {
        this.value = value;
    }

    /**
     * 
     * @return
     *     The assignmentOperation
     */
    @JsonProperty("assignmentOperation")
    public String getAssignmentOperation() {
        return assignmentOperation;
    }

    /**
     * 
     * @param assignmentOperation
     *     The assignmentOperation
     */
    @JsonProperty("assignmentOperation")
    public void setAssignmentOperation(String assignmentOperation) {
        this.assignmentOperation = assignmentOperation;
    }

    /**
     * 
     * @return
     *     The unassignmentOperation
     */
    @JsonProperty("unassignmentOperation")
    public String getUnassignmentOperation() {
        return unassignmentOperation;
    }

    /**
     * 
     * @param unassignmentOperation
     *     The unassignmentOperation
     */
    @JsonProperty("unassignmentOperation")
    public void setUnassignmentOperation(String unassignmentOperation) {
        this.unassignmentOperation = unassignmentOperation;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(name).append(value).append(assignmentOperation).append(unassignmentOperation).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Value) == false) {
            return false;
        }
        Value rhs = ((Value) other);
        return new EqualsBuilder().append(name, rhs.name).append(value, rhs.value).append(assignmentOperation, rhs.assignmentOperation).append(unassignmentOperation, rhs.unassignmentOperation).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
