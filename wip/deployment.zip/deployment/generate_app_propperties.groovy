import groovy.text.Template
import groovy.text.SimpleTemplateEngine

def appEnv = "dev"
def appEnvConfigFile = "C:\\opt\\workspaces\\scripting\\deployment\\config\\${appEnv}_config_data.properties"
def templateFile = "C:\\opt\\workspaces\\scripting\\deployment\\templates\\app_properties.tpl"

def loadConfigData(String file){
    Properties data = new Properties()
    appConfigData = new File(file)
    appConfigData.withInputStream{
        data.load(it)
    }
    return data
}

def databaseUrl = "database.url"
def databaseDriver = "database.driver"
def databaseUsername = "database.username"
def databasePassword = "database.password"

Properties loadedConfigData = loadConfigData(appEnvConfigFile)

def binding = [cfg:loadedConfigData]

def templateEngine = new SimpleTemplateEngine()
def appConfigTemplate = new File(templateFile)
def template = templateEngine.createTemplate(appConfigTemplate).make(binding)
println template.toString()

def outputDir = "C:\\tmp"
def appPropertiesFile = new File(outputDir + File.separator + "app.properties")
appPropertiesFile.withPrintWriter{ pwriter ->
    pwriter.println template.toString()
}