Closure square = { num -> num * num}

def triple = { it * it * it}

square 3

day = "Sunday"
whatDay = { println "today is $day"}
//closures can access the scope ot its parent
whatDay()

void completeTrans(int transId, Closure closure){
    println("executing transaction $transId")
    closure()
}
int transId = 37195

completeTrans(transId) { println "auditing executed transaction: $transId" }
