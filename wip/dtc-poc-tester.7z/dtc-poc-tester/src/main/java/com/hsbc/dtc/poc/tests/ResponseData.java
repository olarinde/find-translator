package com.hsbc.dtc.poc.tests;

public class ResponseData {

}
