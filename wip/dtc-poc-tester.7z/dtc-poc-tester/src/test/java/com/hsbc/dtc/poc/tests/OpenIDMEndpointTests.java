package com.hsbc.dtc.poc.tests;

import static org.junit.Assert.*;

import javax.swing.plaf.ActionMapUIResource;

import org.forgerock.openidm.external.rest.RestService;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class OpenIDMEndpointTests {

//    curl –header “Content-Type: application/json”
//
//    –header “X-OpenIDM-Username: openidm-admin”
//
//    –header “X-OpenIDM-Password: openidm-admin”
//
//    –request PUT –data ‘{ “userName”:”joe”, “givenName”:”joe”, “familyName”:”smith”, “email”:”joe@example.com”, “phoneNumber”:”555-123-1234″, “password”:”TestPassw0rd”, “description”:”My first user” }’ http://localhost:8080/openidm/managed/user/joe

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void test() {
        RestService restService = null;
        fail("Not yet implemented");
    }

}
