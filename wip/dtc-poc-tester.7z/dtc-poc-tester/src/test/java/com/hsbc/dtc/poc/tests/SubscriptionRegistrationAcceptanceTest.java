package com.hsbc.dtc.poc.tests;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import gherkin.formatter.model.Feature;

import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty",
                            "html:target/acceptance_test_report_html",
                            "json:target/acceptance_test_report" },
                            features = {"classpath:bdd/features"},
                            tags = {"~@ignore"})
public class SubscriptionRegistrationAcceptanceTest {
}
