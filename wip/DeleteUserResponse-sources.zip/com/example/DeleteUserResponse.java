
package com.example;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "_id",
    "_rev",
    "mail",
    "sn",
    "givenName",
    "telephoneNumber",
    "userName",
    "description",
    "displayName",
    "accountStatus",
    "effectiveRoles",
    "effectiveAssignments"
})
public class DeleteUserResponse {

    @JsonProperty("_id")
    private String id;
    @JsonProperty("_rev")
    private String rev;
    @JsonProperty("mail")
    private String mail;
    @JsonProperty("sn")
    private String sn;
    @JsonProperty("givenName")
    private String givenName;
    @JsonProperty("telephoneNumber")
    private String telephoneNumber;
    @JsonProperty("userName")
    private String userName;
    @JsonProperty("description")
    private String description;
    @JsonProperty("displayName")
    private String displayName;
    @JsonProperty("accountStatus")
    private String accountStatus;
    @JsonProperty("effectiveRoles")
    private List<Object> effectiveRoles = null;
    @JsonProperty("effectiveAssignments")
    private List<Object> effectiveAssignments = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    /**
     * No args constructor for use in serialization
     * 
     */
    public DeleteUserResponse() {
    }

    /**
     * 
     * @param id
     * @param mail
     * @param sn
     * @param rev
     * @param accountStatus
     * @param description
     * @param telephoneNumber
     * @param effectiveAssignments
     * @param userName
     * @param givenName
     * @param effectiveRoles
     * @param displayName
     */
    public DeleteUserResponse(String id, String rev, String mail, String sn, String givenName, String telephoneNumber, String userName, String description, String displayName, String accountStatus, List<Object> effectiveRoles, List<Object> effectiveAssignments) {
        super();
        this.id = id;
        this.rev = rev;
        this.mail = mail;
        this.sn = sn;
        this.givenName = givenName;
        this.telephoneNumber = telephoneNumber;
        this.userName = userName;
        this.description = description;
        this.displayName = displayName;
        this.accountStatus = accountStatus;
        this.effectiveRoles = effectiveRoles;
        this.effectiveAssignments = effectiveAssignments;
    }

    /**
     * 
     * @return
     *     The id
     */
    @JsonProperty("_id")
    public String getId() {
        return id;
    }

    /**
     * 
     * @param id
     *     The _id
     */
    @JsonProperty("_id")
    public void setId(String id) {
        this.id = id;
    }

    public DeleteUserResponse withId(String id) {
        this.id = id;
        return this;
    }

    /**
     * 
     * @return
     *     The rev
     */
    @JsonProperty("_rev")
    public String getRev() {
        return rev;
    }

    /**
     * 
     * @param rev
     *     The _rev
     */
    @JsonProperty("_rev")
    public void setRev(String rev) {
        this.rev = rev;
    }

    public DeleteUserResponse withRev(String rev) {
        this.rev = rev;
        return this;
    }

    /**
     * 
     * @return
     *     The mail
     */
    @JsonProperty("mail")
    public String getMail() {
        return mail;
    }

    /**
     * 
     * @param mail
     *     The mail
     */
    @JsonProperty("mail")
    public void setMail(String mail) {
        this.mail = mail;
    }

    public DeleteUserResponse withMail(String mail) {
        this.mail = mail;
        return this;
    }

    /**
     * 
     * @return
     *     The sn
     */
    @JsonProperty("sn")
    public String getSn() {
        return sn;
    }

    /**
     * 
     * @param sn
     *     The sn
     */
    @JsonProperty("sn")
    public void setSn(String sn) {
        this.sn = sn;
    }

    public DeleteUserResponse withSn(String sn) {
        this.sn = sn;
        return this;
    }

    /**
     * 
     * @return
     *     The givenName
     */
    @JsonProperty("givenName")
    public String getGivenName() {
        return givenName;
    }

    /**
     * 
     * @param givenName
     *     The givenName
     */
    @JsonProperty("givenName")
    public void setGivenName(String givenName) {
        this.givenName = givenName;
    }

    public DeleteUserResponse withGivenName(String givenName) {
        this.givenName = givenName;
        return this;
    }

    /**
     * 
     * @return
     *     The telephoneNumber
     */
    @JsonProperty("telephoneNumber")
    public String getTelephoneNumber() {
        return telephoneNumber;
    }

    /**
     * 
     * @param telephoneNumber
     *     The telephoneNumber
     */
    @JsonProperty("telephoneNumber")
    public void setTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
    }

    public DeleteUserResponse withTelephoneNumber(String telephoneNumber) {
        this.telephoneNumber = telephoneNumber;
        return this;
    }

    /**
     * 
     * @return
     *     The userName
     */
    @JsonProperty("userName")
    public String getUserName() {
        return userName;
    }

    /**
     * 
     * @param userName
     *     The userName
     */
    @JsonProperty("userName")
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public DeleteUserResponse withUserName(String userName) {
        this.userName = userName;
        return this;
    }

    /**
     * 
     * @return
     *     The description
     */
    @JsonProperty("description")
    public String getDescription() {
        return description;
    }

    /**
     * 
     * @param description
     *     The description
     */
    @JsonProperty("description")
    public void setDescription(String description) {
        this.description = description;
    }

    public DeleteUserResponse withDescription(String description) {
        this.description = description;
        return this;
    }

    /**
     * 
     * @return
     *     The displayName
     */
    @JsonProperty("displayName")
    public String getDisplayName() {
        return displayName;
    }

    /**
     * 
     * @param displayName
     *     The displayName
     */
    @JsonProperty("displayName")
    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public DeleteUserResponse withDisplayName(String displayName) {
        this.displayName = displayName;
        return this;
    }

    /**
     * 
     * @return
     *     The accountStatus
     */
    @JsonProperty("accountStatus")
    public String getAccountStatus() {
        return accountStatus;
    }

    /**
     * 
     * @param accountStatus
     *     The accountStatus
     */
    @JsonProperty("accountStatus")
    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    public DeleteUserResponse withAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
        return this;
    }

    /**
     * 
     * @return
     *     The effectiveRoles
     */
    @JsonProperty("effectiveRoles")
    public List<Object> getEffectiveRoles() {
        return effectiveRoles;
    }

    /**
     * 
     * @param effectiveRoles
     *     The effectiveRoles
     */
    @JsonProperty("effectiveRoles")
    public void setEffectiveRoles(List<Object> effectiveRoles) {
        this.effectiveRoles = effectiveRoles;
    }

    public DeleteUserResponse withEffectiveRoles(List<Object> effectiveRoles) {
        this.effectiveRoles = effectiveRoles;
        return this;
    }

    /**
     * 
     * @return
     *     The effectiveAssignments
     */
    @JsonProperty("effectiveAssignments")
    public List<Object> getEffectiveAssignments() {
        return effectiveAssignments;
    }

    /**
     * 
     * @param effectiveAssignments
     *     The effectiveAssignments
     */
    @JsonProperty("effectiveAssignments")
    public void setEffectiveAssignments(List<Object> effectiveAssignments) {
        this.effectiveAssignments = effectiveAssignments;
    }

    public DeleteUserResponse withEffectiveAssignments(List<Object> effectiveAssignments) {
        this.effectiveAssignments = effectiveAssignments;
        return this;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    public DeleteUserResponse withAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
        return this;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(id).append(rev).append(mail).append(sn).append(givenName).append(telephoneNumber).append(userName).append(description).append(displayName).append(accountStatus).append(effectiveRoles).append(effectiveAssignments).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof DeleteUserResponse) == false) {
            return false;
        }
        DeleteUserResponse rhs = ((DeleteUserResponse) other);
        return new EqualsBuilder().append(id, rhs.id).append(rev, rhs.rev).append(mail, rhs.mail).append(sn, rhs.sn).append(givenName, rhs.givenName).append(telephoneNumber, rhs.telephoneNumber).append(userName, rhs.userName).append(description, rhs.description).append(displayName, rhs.displayName).append(accountStatus, rhs.accountStatus).append(effectiveRoles, rhs.effectiveRoles).append(effectiveAssignments, rhs.effectiveAssignments).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
